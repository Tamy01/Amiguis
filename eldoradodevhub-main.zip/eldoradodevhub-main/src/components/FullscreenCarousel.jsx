import React, { useState, useEffect, useRef } from "react"

const FullscreenCarousel = ({ children }) => {
  const [currentIndex, setCurrentIndex] = useState(0)
  const carouselRef = useRef(null)
  const cards = React.Children.toArray(children)
  const windowHeight = window.innerHeight
  const scrollThreshold = windowHeight * 0.1 // 10% de la altura de la tarjeta

  useEffect(() => {
    const handleScroll = () => {
      const carousel = carouselRef.current
      const scrollPosition =
        window.pageYOffset || document.documentElement.scrollTop
      const targetIndex = Math.round(
        (scrollPosition + scrollThreshold) / windowHeight
      )

      if (targetIndex !== currentIndex) {
        setCurrentIndex(targetIndex)
        carousel.scrollTo({
          top: targetIndex * windowHeight,
          behavior: "smooth",
        })
      }
    }

    const carousel = carouselRef.current
    carousel.addEventListener("scroll", handleScroll)
    return () => carousel.removeEventListener("scroll", handleScroll)
  }, [currentIndex, windowHeight, scrollThreshold])

  return (
    <div
      ref={carouselRef}
      style={{ height: `${cards.length * 100}vh`, overflowY: "auto" }}
    >
      {cards.map((card, index) => (
        <div
          key={index}
          style={{
            height: "100vh",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {card}
        </div>
      ))}
    </div>
  )
}

export default FullscreenCarousel
