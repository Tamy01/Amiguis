import React, { useEffect, useRef } from "react"

function ScrollCenteredFullscreenCard({ children }) {
  const cardRefs = useRef([])
  const prevScrollY = useRef(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY
      const scrollDirection = scrollY > prevScrollY.current ? "down" : "up"

      prevScrollY.current = scrollY

      cardRefs.current.forEach((ref, index) => {
        const rect = ref.getBoundingClientRect()
        const isTopVisible = rect.top >= 0 && rect.top <= window.innerHeight
        const isBottomVisible =
          rect.bottom >= 0 && rect.bottom <= window.innerHeight

        if ((isTopVisible || isBottomVisible) && scrollDirection === "down") {
          window.scrollTo({
            top: ref.offsetTop,
            behavior: "smooth",
          })
        } else if (isTopVisible && scrollDirection === "up" && index > 0) {
          window.scrollTo({
            top: cardRefs.current[index - 1].offsetTop,
            behavior: "smooth",
          })
        }
      })
    }

    // Agregar el evento de scroll
    window.addEventListener("scroll", handleScroll)

    // Limpiar el evento de scroll al desmontar el componente
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  return (
    <div>
      {React.Children.map(children, (child, index) => {
        return (
          <div key={index} ref={(el) => el && cardRefs.current.push(el)}>
            {child}
          </div>
        )
      })}
    </div>
  )
}

export default ScrollCenteredFullscreenCard
