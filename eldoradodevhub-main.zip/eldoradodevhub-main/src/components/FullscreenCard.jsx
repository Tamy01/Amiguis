// eslint-disable-next-line react/prop-types
const FullscreenCard = ({ children, foto }) => {
  return (
    <div
      style={{
        // width: cardDimensions.width,
        // height: cardDimensions.height,
        // backgroundColor: color,
        height: "100vh",
        width: "100vw",
        display: "grid",
        position: "relative",
        backgroundImage: `url(${foto})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        scrollSnapAlign: "center",
        // flex: "none",
        textAlign: "center",
        placeItems: "center",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {children}
    </div>
  )
}

export default FullscreenCard
