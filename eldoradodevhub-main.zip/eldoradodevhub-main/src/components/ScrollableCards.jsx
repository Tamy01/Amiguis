import React, { useState, useEffect } from "react"

const ScrollableCards = ({ children }) => {
  const [currentCardIndex, setCurrentCardIndex] = useState(0)
  const [scrollPosition, setScrollPosition] = useState(0)
  const cards = React.Children.toArray(children)
  const windowHeight = window.innerHeight

  useEffect(() => {
    const handleScroll = () => {
      const newScrollPosition =
        window.pageYOffset || document.documentElement.scrollTop
      const targetIndex = Math.round(newScrollPosition / windowHeight)

      if (targetIndex !== currentCardIndex) {
        setCurrentCardIndex(targetIndex)
        setScrollPosition(newScrollPosition)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [currentCardIndex, windowHeight])

  return (
    <div style={{ height: `${cards.length * 100}vh` }}>
      {cards.map((card, index) => (
        <div
          key={index}
          style={{
            height: "100vh",
            position: "sticky",
            top: 0,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            transform: `translateY(${
              index <= currentCardIndex
                ? (currentCardIndex - index) * windowHeight
                : 0
            }px)`,
            transition: "transform 0.5s ease",
          }}
        >
          {card}
        </div>
      ))}
    </div>
  )
}

export default ScrollableCards
