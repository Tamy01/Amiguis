import { useState, useEffect } from "react"
import styled from "styled-components"

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  overflow-y: auto;
  height: 100vh;
  scroll-snap-type: y mandatory; /* Add scroll snapping */
`

const FullscreenCard = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  scroll-snap-align: start; /* Add scroll snap alignment */
`

const FullscreenCardComponent = ({ children }) => {
  const [cardDimensions, setCardDimensions] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  })

  useEffect(() => {
    const handleResize = () => {
      setCardDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      })
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return (
    <Container>
      <FullscreenCard>{children}</FullscreenCard>
    </Container>
  )
}

export default FullscreenCardComponent
