import React, { useState, useEffect } from "react"

const ScrollableCards = ({ children }) => {
  const [currentCardIndex, setCurrentCardIndex] = useState(0)
  const cards = React.Children.toArray(children)

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition =
        window.pageYOffset || document.documentElement.scrollTop
      const windowHeight = window.innerHeight
      const targetIndex = Math.round(scrollPosition / windowHeight)

      if (targetIndex !== currentCardIndex) {
        setCurrentCardIndex(targetIndex)
        window.scrollTo(0, targetIndex * windowHeight)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [currentCardIndex])

  return (
    <div style={{ height: `${cards.length * 100}vh` }}>
      {cards.map((card, index) => (
        <div
          key={index}
          style={{
            height: "100vh",
            position: "sticky",
            top: 0,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {card}
        </div>
      ))}
    </div>
  )
}

export default ScrollableCards
