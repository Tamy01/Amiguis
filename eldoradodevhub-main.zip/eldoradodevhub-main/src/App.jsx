import logo from "./assets/LogoEDH.svg"
import "./App.css"
import FullscreenCard from "./components/FullscreenCard"

import videoSource from "./assets/video/tele.webm"

import presentacion from "./assets/imagen/presentacion.jpeg"
import ladrillos_recog from "./assets/imagen/ladrillo_recog.png"
import acopio_materiales from "./assets/imagen/acopio_materiales.png"
import equipo_seguridad from "./assets/imagen/equipo_seguridad.png"
import objetivos from "./assets/imagen/objetivos.png"
import trompo_gps from "./assets/imagen/trompo_gps.png"
import mov_materiales from "./assets/imagen/mov_materiales.png"

function App() {
  return (
    <>
      <div>
        <div className="container">
          <FullscreenCard foto={presentacion}>
            <div className="logo">
              <a href="mailto:quierosoluciones@eldoradosrl.ar">
                <img src={logo} className="logo" alt="ELDH logo" />
              </a>
            </div>
            <div className="read-the-docs">
              <p className="read-text">
                La empresa El Dorado, presente en el mercado hace casi 20 años,
                inició hace 2 años actividades de desarrollo tecnológico e
                innovación, orientados inicialmente hacia el desarrollo de
                soluciones tecnológicas para consumo propio.
              </p>
            </div>
            <div className="read-the-docs">
              <p className="read-text">
                Muchos de los proyectos tienen potencial para su utilización en
                otros emprendimientos. Por ello, describimos los proyectos más
                relevantes a continuación. En caso de que alguno resulte de su
                interés, no dude en contactarnos.
              </p>
            </div>
          </FullscreenCard>

          <FullscreenCard foto={equipo_seguridad}>
            <h1 className="titulo">Visión computacional: Detección de EPP</h1>
            <div className="read-the-docs">
              <p className="read-text">
                La empresa desarrolla una aplicación que permita identificar el
                adecuado uso de elementos de protección personal a través del
                entrenamiento de sistemas de inteligencia artificial. Esto
                permite asegurar que en las zonas peligrosas de la fábrica el
                personal use los EPP necesarios, permitiendo trabajar en la
                prevención de accidentes. El entrenamiento genérico permite
                identificar los EPP y el entrenamiento específico permite
                utilizar los sistemas de videovigilancia ya disponibles para
                marcar zonas peligrosas dentro de la planta, entre muchas otras
                opciones.
              </p>
            </div>
            {/* <video width={"auto"} autoPlay loop muted playsInline>
              <source src={videoSource} type="video/webm" />
              Tu navegador no soporta la etiqueta de video.
            </video> */}
          </FullscreenCard>

          <FullscreenCard foto={acopio_materiales}>
            <h1 className="titulo">
              Implementación de software: Gestión de inventarios mediante
              telemetría de acopios
            </h1>
            <div className="read-the-docs">
              <p className="read-text">
                La empresa implementó sistemas para detección y medición de
                acopios a granel de materias primas (arcillas, arena, piedra,
                etc) mediante telemetría por sobrevuelo de drone. Este sistema
                permite tener mediciones precisas del volumen del acopio a
                partir de fotografías aéreas de la zona a medir, con un esfuerzo
                reducido en tiempo y procesamiento.
              </p>
            </div>
            {/* <video width={"auto"} autoPlay loop muted playsInline>
              <source src={videoSource} type="video/webm" />
              Tu navegador no soporta la etiqueta de video.
            </video> */}
          </FullscreenCard>

          <FullscreenCard foto={objetivos}>
            <h1 className="titulo">
              Desarrollo de software: Sistema de objetivos y tableros de
              monitoreo
            </h1>
            <div className="read-the-docs">
              <p className="read-text">
                El Dorado desarrollo un software propio para registrar los
                objetivos de toda la empresa mediante una estructura jerárquica,
                integrando todos los indicadores en una única herramienta y
                pudiendo visualizarlos de un rápido pantallazo por la alta
                dirección, con el nivel de detalle que consideren conveniente.
                Integra los objetivos formulados para cada área, los indicadores
                seleccionados para su medición, y las metas o parámetros de
                semaforización adoptados. Asiste a la alta dirección sobre
                desvíos utilizando controladores PID y matemática borrosa de muy
                sencilla implementación.
              </p>
            </div>
          </FullscreenCard>

          <FullscreenCard foto={ladrillos_recog}>
            <h1 className="titulo">
              Visión computacional: Clasificación de ladrillos
            </h1>
            <div className="read-the-docs">
              <p className="read-text">
                La empresa está desarrollando herramientas de IA para la
                clasificación de ladrillos, entrenada para diferencias los
                modelos y calidades diferentes. Esta herramienta permitirá un
                control de producción preciso, un seguimiento trazable del
                proceso de secado, y eventualmente, el futuro entrenamiento de
                algoritmos para optimizar los procesos de secado según las
                condiciones ambientales.
              </p>
            </div>
          </FullscreenCard>

          <FullscreenCard foto={trompo_gps}>
            <h1 className="titulo">
              Desarrollo de hardware: Seguimiento GPS de la flota
            </h1>
            <div className="read-the-docs">
              <p className="read-text">
                La empresa está desarrollando hardware para el seguimiento de la
                flota y la telemetría de muchos parámetros de los procesos de
                entrega, incluyendo tiempos de viaje, tiempos de descarga,
                condiciones del material al momento de descargar, cantidades
                pendientes de descarga, etcétera.
              </p>
            </div>
          </FullscreenCard>

          <FullscreenCard foto={mov_materiales}>
            <h1 className="titulo">
              Visión computacional: Movimientos de materias primas
            </h1>
            <div className="read-the-docs">
              <p className="read-text">
                La empresa está desarrollando sistemas de identificación de
                equipos de manipulación de inventarios (cargadoras frontales,
                montacargas) para cuantificar los movimientos de materias primas
                reemplazando registros manuales de poca confiabilidad,
                permitiendo calcular el rendimiento efectivo de algunos procesos
                que de otra manera resultaban imposibles de controlar.
              </p>
            </div>
          </FullscreenCard>
        </div>
      </div>
    </>
  )
}

export default App
